-- Optional: star motes shed off the bones while moving.
-- Delete this file if you only want the material work.
-- gxskel_trail 0/1   gxskel_trail_dist <units>

local MDL = "models/gruchk/oc/galaxy_skeleton.mdl"
local cv_on = CreateClientConVar("gxskel_trail", "1", true, false,
	"Galaxy Skeleton: shed star motes while moving")
local cv_dist = CreateClientConVar("gxskel_trail_dist", "1400", true, false,
	"Galaxy Skeleton: max render distance for motes")

local MAT = "sprites/light_glow02_add"
local PAL = {
	Color(150, 110, 255), Color(255, 120, 200),
	Color(110, 200, 255), Color(235, 225, 255),
}

local emitter, nextEmit = nil, {}

local function motes(ply, speed)
	local pos = ply:WorldSpaceCenter()
	if not emitter then emitter = ParticleEmitter(pos, false) end
	emitter:SetPos(pos)

	local mins, maxs = ply:OBBMins(), ply:OBBMaxs()
	for _ = 1, math.Clamp(math.floor(speed / 130), 1, 3) do
		local src = ply:LocalToWorld(Vector(
			math.Rand(mins.x, maxs.x) * 0.7,
			math.Rand(mins.y, maxs.y) * 0.7,
			math.Rand(mins.z, maxs.z)))

		local p = emitter:Add(MAT, src)
		if not p then return end

		local c = PAL[math.random(#PAL)]
		p:SetVelocity(VectorRand() * 6 + Vector(0, 0, math.Rand(4, 14)))
		p:SetDieTime(math.Rand(0.5, 1.15))
		p:SetStartAlpha(math.random(120, 210))
		p:SetEndAlpha(0)
		p:SetStartSize(math.Rand(1.4, 3.6))
		p:SetEndSize(0)
		p:SetColor(c.r, c.g, c.b)
		p:SetAirResistance(38)
		p:SetGravity(Vector(0, 0, math.Rand(-2, 6)))
		p:SetCollide(false)
	end
end

hook.Add("Think", "gxskel_trail", function()
	if not cv_on:GetBool() then return end

	local eye = EyePos()
	local maxd = cv_dist:GetFloat() ^ 2
	local now = CurTime()

	for _, ply in ipairs(player.GetAll()) do
		if ply:IsValid() and ply:Alive() and ply:GetModel() == MDL
			and not ply:GetNoDraw() then

			if not (ply == LocalPlayer() and not ply:ShouldDrawLocalPlayer()) then
				local speed = ply:GetVelocity():Length()
				if speed > 90 and eye:DistToSqr(ply:WorldSpaceCenter()) < maxd then
					if (nextEmit[ply] or 0) < now then
						nextEmit[ply] = now + 0.045
						motes(ply, speed)
					end
				end
			end
		end
	end
end)

hook.Add("ShutDown", "gxskel_trail_cleanup", function()
	if emitter then emitter:Finish() emitter = nil end
end)
