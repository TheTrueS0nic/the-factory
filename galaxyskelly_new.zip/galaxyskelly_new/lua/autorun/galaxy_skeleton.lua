-- GALAXY SKELETON | Playermodel
-- bones retextured as deep space; jeans + vans untouched.
-- skins: 0 = violet   1 = ice   2 = nova   3 = toxic   (SetSkin / model menu)

local MDL   = "models/gruchk/oc/galaxy_skeleton.mdl"
local HANDS = "models/gruchk/oc/c_arms_galaxy.mdl"

list.Set("PlayerOptionsModel", "Galaxy Skeleton", MDL)
player_manager.AddValidModel("Galaxy Skeleton", MDL)
player_manager.AddValidHands("Galaxy Skeleton", HANDS, 0, "00000000")

if SERVER then
	resource.AddWorkshop = resource.AddWorkshop -- noop guard
end
